import numpy as np
import tensorflow as tf
import json
import random
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from sklearn.preprocessing import LabelEncoder

# Load dataset
with open("intents.json") as file:
    data = json.load(file)

# Preprocess the data
training_sentences = []
training_labels = []
classes = []
responses = {}

for intent in data["intents"]:
    for pattern in intent["patterns"]:
        training_sentences.append(pattern)
        training_labels.append(intent["tag"])
    if intent["tag"] not in classes:
        classes.append(intent["tag"])
    responses[intent["tag"]] = intent["responses"]

# Encode labels
lbl_encoder = LabelEncoder()
training_labels = lbl_encoder.fit_transform(training_labels)

# Tokenization and padding
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

vocab_size = 1000
embedding_dim = 16
max_len = 20
oov_token = "<OOV>"

tokenizer = Tokenizer(num_words=vocab_size, oov_token=oov_token)
tokenizer.fit_on_texts(training_sentences)
sequences = tokenizer.texts_to_sequences(training_sentences)
padded_sequences = pad_sequences(sequences, truncating="post", maxlen=max_len)

# Model definition
model = Sequential([
    tf.keras.layers.Embedding(vocab_size, embedding_dim, input_length=max_len),
    tf.keras.layers.GlobalAveragePooling1D(),
    tf.keras.layers.Dense(16, activation="relu"),
    Dropout(0.2),
    tf.keras.layers.Dense(16, activation="relu"),
    Dropout(0.2),
    tf.keras.layers.Dense(len(classes), activation="softmax")
])

model.compile(loss="sparse_categorical_crossentropy", optimizer="adam", metrics=["accuracy"])
model.summary()

# Train the model
epochs = 500
history = model.fit(padded_sequences, np.array(training_labels), epochs=epochs, verbose=1)

# Save the model
model.save("chatbot_model.keras")  # Save in native Keras format
print("Model trained and saved!")


import pickle

with open("tokenizer.pickle", "wb") as handle:
    pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)

with open("label_encoder.pickle", "wb") as enc_file:
    pickle.dump(lbl_encoder, enc_file, protocol=pickle.HIGHEST_PROTOCOL)

print("Model trained and saved!")

# Chatbot response function
def chatbot_response(input_text):
    with open("tokenizer.pickle", "rb") as handle:
        tokenizer = pickle.load(handle)

    with open("label_encoder.pickle", "rb") as enc_file:
        lbl_encoder = pickle.load(enc_file)

    model = tf.keras.models.load_model("chatbot_model.keras")

    result = model.predict(pad_sequences(tokenizer.texts_to_sequences([input_text]),
                                         truncating="post", maxlen=max_len))
    tag = lbl_encoder.inverse_transform([np.argmax(result)])
    
    for intent in data["intents"]:
        if intent["tag"] == tag:
            return random.choice(intent["responses"])

# Run chatbot
print("Start chatting with the bot! Type 'quit' to stop.")

while True:
    user_input = input("You: ")
    if user_input.lower() == "quit":
        break
    response = chatbot_response(user_input)
    print(f"Bot: {response}")
